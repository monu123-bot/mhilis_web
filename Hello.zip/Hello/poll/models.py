from django.db import models

# Create your models here.
class Online_Courses(models.Model):
    id1 = models.CharField(max_length=2)
    name = models.CharField(max_length=122)
    phone = models.CharField(max_length=122)
    course = models.CharField(max_length=122)
    address = models.CharField(max_length=300)
    


    