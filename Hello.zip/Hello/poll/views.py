from django.shortcuts import render,redirect
from django.contrib.auth import authenticate
from django.contrib.auth import logout,login
from django.contrib import messages
from django.views.generic import View
from .forms import *
from datetime import datetime
from poll.models import Online_Courses
# Create your views here.

def signUpview(request):
  return render(request,"signup.html")

   
def index(request):
    current_user = request.user
    username = current_user.username
    context = {}
    context['user_name'] = username

    if request.user.is_anonymous:
        return redirect('/login')
    return  render(request,'index.html',context)    
    
class signupview(View):
  def get(self,request):
    fm = signUpform()
    return render(request,"signup.html" , {'form':fm})
  def post(self,request):
    fm = signUpform(request.POST)
    if fm.is_valid():
         fm.save() 
         messages.success(request,'Sign Up success !')
         return redirect('/signup')
    else:
      return render(request,"signup.html" , {'form':fm})


       

def loginUser(request):
    
       username = request.POST.get('username')
       password = request.POST.get('password')
       user = authenticate( username=username, password=password)
       if user is not None:
          login(request,user)  
        # Redirect to a success page.
          return redirect('/')
        
       else:
        # Return an 'invalid login' error message.
          return  render(request,'login.html')

    
def logoutUser(request):
   logout(request) 
   return redirect('/login')  
def about(request):
    return render(request,"about.html")
def contact(request):
   return render(request,"contact.html")
def service(request):
    current_user = request.user
    username = current_user.username
    if request.method == "POST":
      id1 = request.POST.get("id1")
      name = request.POST.get("name")
      phone = request.POST.get("phone")
      course = request.POST.get("course")
      address = request.POST.get("address")
      print(id1,name,course,address)

      course_ = Online_Courses(id1,name,phone,course,address)
      course_.save()       
    return render(request,"services.html" )    


    

