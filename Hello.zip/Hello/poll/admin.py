from django.contrib import admin
from poll.models import Online_Courses

admin.site.register(Online_Courses)
